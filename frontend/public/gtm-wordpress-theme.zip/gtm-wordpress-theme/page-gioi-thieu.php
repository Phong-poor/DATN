<?php
if (!defined('ABSPATH')) { exit; }
gtm_media_output_static_page('gioi-thieu.html');
