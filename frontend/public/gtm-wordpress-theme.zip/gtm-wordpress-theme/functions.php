<?php
if (!defined('ABSPATH')) { exit; }

function gtm_media_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'gtm_media_theme_setup');

function gtm_media_replace_static_paths($buffer) {
    $theme_uri = get_template_directory_uri();
    $home = home_url('/');
    $replacements = array(
        'href="assets/' => 'href="' . $theme_uri . '/assets/',
        'src="assets/' => 'src="' . $theme_uri . '/assets/',
        "href='assets/" => "href='" . $theme_uri . "/assets/",
        "src='assets/" => "src='" . $theme_uri . "/assets/",
        'href="css/' => 'href="' . $theme_uri . '/css/',
        'src="css/' => 'src="' . $theme_uri . '/css/',
        'href="js/' => 'href="' . $theme_uri . '/js/',
        'src="js/' => 'src="' . $theme_uri . '/js/',
        'src="banner.png"' => 'src="' . $theme_uri . '/banner.png"',
        'href="index.html"' => 'href="' . $home . '"',
        'href="gioi-thieu.html"' => 'href="' . home_url('/gioi-thieu/') . '"',
        'href="lien-he.html"' => 'href="' . home_url('/lien-he/') . '"',
        'href="tin-tuc.html"' => 'href="' . home_url('/tin-tuc/') . '"',
        'href="dong-phuc-y-te.html"' => 'href="' . home_url('/dong-phuc-y-te/') . '"',
        'href="dong-phuc-cong-so.html"' => 'href="' . home_url('/dong-phuc-cong-so/') . '"',
        'href="dong-phuc-nha-hang.html"' => 'href="' . home_url('/dong-phuc-nha-hang/') . '"',
        'href="dong-phuc-tham-my.html"' => 'href="' . home_url('/dong-phuc-tham-my/') . '"',
        'href="hang-may-san.html"' => 'href="' . home_url('/hang-may-san/') . '"',
    );
    return strtr($buffer, $replacements);
}

function gtm_media_output_static_page($file) {
    $path = get_template_directory() . '/static-html/' . $file;
    if (!file_exists($path)) { status_header(404); echo 'Page not found'; return; }
    ob_start();
    include $path;
    $html = ob_get_clean();
    $html = gtm_media_replace_static_paths($html);
    $html = str_replace('</head>', '<?php wp_head(); ?></head>', $html);
    $html = str_replace('</body>', '<?php wp_footer(); ?></body>', $html);
    // Execute injected wp_head/wp_footer tags safely by evaluating as template fragment.
    eval('?>' . $html);
}
