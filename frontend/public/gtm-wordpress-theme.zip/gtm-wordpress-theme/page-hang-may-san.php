<?php
if (!defined('ABSPATH')) { exit; }
gtm_media_output_static_page('hang-may-san.html');
