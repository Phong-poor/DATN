function initHotline() {
    // Check if it's already injected to prevent duplicates
    if (document.querySelector('.hotline-wrapper')) return;

    // Inject CSS for hotline
    const style = document.createElement('style');
    style.innerHTML = `
        .hotline-wrapper { position: fixed !important; bottom: 20px !important; left: 50% !important; right: auto !important; transform: translateX(-50%) !important; display: flex !important; flex-direction: column; align-items: center; z-index: 99999999 !important; gap: 8px; }
        .hotline-label { color: #fff; font-size: 14px; font-weight: bold; background: #000; padding: 4px 12px; border-radius: 16px; }
        .hotline-buttons { display: flex; gap: 14px; }
        .hotline-buttons a { color: #fff; background: #0a74da; padding: 12px 24px; border-radius: 36px; text-decoration: none; font-size: 18px; font-weight: bold; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); display: flex; align-items: center; justify-content: center; white-space: nowrap; }
        .hotline-buttons a.red { background: #dc3545; }
        @media (max-width: 1024px) { .hotline-buttons a { font-size: 14px; padding: 8px 16px; border-radius: 24px; } }
        @media (max-width: 600px) { .hotline-buttons { flex-direction: column; gap: 8px; } .hotline-buttons a { font-size: 13px; padding: 6px 12px; border-radius: 20px; } }
        .devvn_toolbar { position: fixed; bottom: 15%; left: 10px; z-index: 99999999; }
        .devvn_toolbar ul { list-style: none; margin: 0; padding: 0; }
        .devvn_toolbar ul li { padding: 0; margin: 0; list-style: none; }
        .devvn_toolbar ul li a { display: block; width: 40px; height: 40px; border-radius: 50%; -moz-border-radius: 50%; -webkit-border-radius: 50%; margin: 0 0 5px; position: relative; background-position: 50% 50%; background-size: cover; }
        .devvn_toolbar ul li a br { display: none; }
        .devvn_toolbar ul li a span { font-weight: 400; color: #ffffff; position: absolute; top: 50%; left: calc(100% + 10px); margin-top: -12.5px; font-size: 14px; height: 25px; line-height: 25px; padding: 0 10px; border-radius: 5px; white-space: nowrap; opacity: 0; visibility: hidden; }
        .devvn_toolbar ul li a:hover span { opacity: 1; visibility: visible; }
        .devvn_toolbar ul li a span:after { right: 100%; top: 50%; border: solid transparent; content: " "; height: 0; width: 0; position: absolute; pointer-events: none; border-color: rgba(136, 183, 213, 0); border-right-color: #ffffff; border-width: 5px; margin-top: -5px; }
        .devvn_toolbar ul li a img { width: auto; height: auto; max-width: 45px; max-height: 45px; position: absolute; top: 50%; left: 50%; transform: translate3d(-50%, -50%, 0); }
        @media (max-width: 560px) { .devvn_toolbar { position: fixed; bottom: 15%; right: 10px; left: unset; z-index: 99999999; } }
        .devvn_toolbar ul li a#devvn_contact_1 span:after { border-right-color: #008000; }
        .devvn_toolbar ul li a#devvn_contact_2 span:after { border-right-color: #e60808; }
        .devvn_toolbar ul li a#devvn_contact_3 span:after { border-right-color: #008fe5; }
        .devvn_toolbar ul li a#devvn_contact_4 span:after { border-right-color: #3b5998; }
    `;
    document.head.appendChild(style);

    // Inject HTML for hotline
    const widget = document.createElement('div');
    widget.innerHTML = '<div class="hotline-wrapper"><div class="hotline-label">🔔 HOTLINE TƯ VẤN</div><div class="hotline-buttons"><a href="tel:02877712758">📞 02877 712 758</a><a href="tel:0916232823" class="red">📞 0916 23 28 23</a></div></div><div class="devvn_toolbar"><ul><li><a target="_blank" href="https://zalo.me/0916232823" id="devvn_contact_3" title="Chat zalo" style="background-color: #008fe5;" rel="noopener"><img src="https://dongphucnadi.com/wp-content/uploads/2024/11/Logo.png" width="60" height="60" alt=""><br><span style="color: #ffffff; background-color: #008fe5;">Chat zalo</span></a></li></ul></div>';
    document.body.appendChild(widget);
    
    // Inject OMI LiveTalk script only if it doesn't exist
    if (!document.getElementById('omiLiveTalk')) {
        const omiScript = document.createElement('script');
        omiScript.id = 'omiLiveTalk';
        omiScript.type = 'text/javascript';
        omiScript.src = 'https://cdn.omicrm.com/script/livetalk/main.js#domain=nadi;';
        document.body.appendChild(omiScript);
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initHotline);
} else {
    initHotline();
}