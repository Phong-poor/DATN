/**
 * components.js - Shared script for all pages
 * Handles: header/footer injection + CSS preloading + lazy image fix
 * 
 * HOW TO USE: Add ONE script tag to any page:
 *   <script src="js/components.js"></script>
 * This replaces the inline loadComponents() and handles everything.
 */

(async function () {
    // ─── 1. Inject required CSS into <head> before anything renders ───────────
    const REQUIRED_CSS = [
        'assets/css/0e855e98369b679bb0d368eb4ace0326.css',  // Main theme (icons, fonts, layout)
        'css/style.css'                                       // Custom overrides
    ];

    function injectCSS(href) {
        // Skip if already loaded
        const existing = document.querySelector('link[href="' + href + '"]');
        if (existing) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = href;
        document.head.appendChild(link);
    }

    REQUIRED_CSS.forEach(injectCSS);

    // ─── 2. Load header + footer components ──────────────────────────────────
    async function loadComponent(id, file) {
        const placeholder = document.getElementById(id);
        if (!placeholder) return;
        try {
            const res = await fetch(file);
            if (res.ok) {
                const html = await res.text();
                // Parse the fetched HTML and extract any <link> tags to move to <head>
                const tmp = document.createElement('div');
                tmp.innerHTML = html;
                tmp.querySelectorAll('link[rel="stylesheet"]').forEach(function (link) {
                    injectCSS(link.getAttribute('href'));
                    link.remove();
                });
                
                // Trích xuất các element cần fixed (như hotline, zalo) ra khỏi footer và gắn thẳng vào body
                if (id === 'footer-placeholder') {
                    tmp.querySelectorAll('.hotline-wrapper, .devvn_toolbar').forEach(function(el) {
                        document.body.appendChild(el);
                    });
                }
                
                placeholder.outerHTML = tmp.innerHTML;
            }
        } catch (e) {
            console.warn('Could not load component: ' + file, e);
        }
    }

    await loadComponent('header-placeholder', 'header.html');
    await loadComponent('footer-placeholder', 'footer.html');

    // ─── 3. Fix LiteSpeed lazy-loaded iframes (e.g. Google Maps) ─────────────
    document.querySelectorAll('iframe[data-litespeed-src]').forEach(function (el) {
        el.setAttribute('src', el.getAttribute('data-litespeed-src'));
    });

    // ─── 4. Fix any remaining lazy-loaded images (data-src → src) ────────────
    document.querySelectorAll('img[data-src]').forEach(function (img) {
        img.setAttribute('src', img.getAttribute('data-src'));
        img.removeAttribute('data-src');
    });

})();
