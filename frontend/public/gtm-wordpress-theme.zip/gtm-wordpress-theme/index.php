<?php
if (!defined('ABSPATH')) { exit; }
$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$map = array(
    '' => 'index.html',
    'gioi-thieu' => 'gioi-thieu.html',
    'lien-he' => 'lien-he.html',
    'tin-tuc' => 'tin-tuc.html',
    'dong-phuc-y-te' => 'dong-phuc-y-te.html',
    'dong-phuc-cong-so' => 'dong-phuc-cong-so.html',
    'dong-phuc-nha-hang' => 'dong-phuc-nha-hang.html',
    'dong-phuc-tham-my' => 'dong-phuc-tham-my.html',
    'hang-may-san' => 'hang-may-san.html',
);
$file = isset($map[$path]) ? $map[$path] : 'index.html';
gtm_media_output_static_page($file);
