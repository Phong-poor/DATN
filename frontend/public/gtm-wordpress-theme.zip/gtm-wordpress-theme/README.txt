GTM Media Static Theme

Cách dùng:
1. Vào WordPress Admin > Appearance > Themes > Add New > Upload Theme.
2. Upload file gtm-wordpress-theme.zip và Activate.
3. Tạo các Page có slug: gioi-thieu, lien-he, tin-tuc, dong-phuc-y-te, dong-phuc-cong-so, dong-phuc-nha-hang, dong-phuc-tham-my, hang-may-san.
4. Vào Settings > Reading, đặt Homepage là trang chủ hoặc để theme tự dùng front-page.php.

Lưu ý:
- Theme này là bản tĩnh chuyển từ HTML/CSS/JS, chưa biến nội dung thành bài viết/sản phẩm động.
- Một số ảnh trong HTML vẫn gọi từ domain gốc dongphucnadi.com nếu export chưa tải về đủ.
- Form/liên hệ/giỏ hàng/WooCommerce nếu có sẽ cần code lại bằng plugin hoặc custom PHP.
