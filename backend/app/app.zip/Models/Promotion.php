<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Đại diện chương trình khuyến mãi và các điều kiện sử dụng mã giảm giá.
 */
class Promotion extends Model
{
    protected $table = 'vouchers';

    public function userVouchers()
    {
        return $this->hasMany(UserVoucher::class, 'id_voucher');
    }

    protected $fillable = [
        'ten',
        'danhmuc',
        'code',
        'ngay_su_kien',
        'tu_dong_gui',
        'loai',
        'giatri',
        'ngaybatdau',
        'ngayketthuc',
        'trangthai',
        'mota',
        'loai_dieu_kien',
        'dieu_kien',
        'congkhai',
        'dieu_kien_tang',
        'so_luong_phat',
    ];

    protected $casts = [
        'tu_dong_gui' => 'boolean',
    ];

    public $timestamps = false;
}
